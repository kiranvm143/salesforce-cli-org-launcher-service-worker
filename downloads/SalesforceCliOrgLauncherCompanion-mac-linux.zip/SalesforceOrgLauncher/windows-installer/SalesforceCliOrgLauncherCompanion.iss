#define MyAppName "Salesforce CLI Org Launcher Companion"
#define MyAppVersion "0.1.19"
#define MyAppPublisher "Kiran Markad"
#ifndef ChromeExtensionId
#define ChromeExtensionId "kanjinfiojebibldeeajnbmgjmdipjjn"
#endif

[Setup]
AppId={{75F10980-46D9-4B74-9E06-99F358AF8AA7}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Salesforce CLI Org Launcher
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=output
OutputBaseFilename=SalesforceCliOrgLauncherCompanionSetup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayName={#MyAppName}

[Files]
Source: "..\dist\native-host\*"; DestDir: "{localappdata}\Salesforce CLI Org Launcher\native-host"; Flags: ignoreversion recursesubdirs createallsubdirs

[Registry]
Root: HKCU; Subkey: "Software\Google\Chrome\NativeMessagingHosts\com.kiran.salesforce_org_launcher"; ValueType: string; ValueName: ""; ValueData: "{localappdata}\SalesforceOrgLauncher\NativeMessagingHosts\com.kiran.salesforce_org_launcher.json"; Flags: uninsdeletekey

[UninstallDelete]
Type: filesandordirs; Name: "{localappdata}\Salesforce CLI Org Launcher\native-host"
Type: files; Name: "{localappdata}\SalesforceOrgLauncher\NativeMessagingHosts\com.kiran.salesforce_org_launcher.json"

[Code]
function JsonEscape(Value: String): String;
begin
  StringChangeEx(Value, '\', '\\', True);
  Result := Value;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  ManifestDir: String;
  ManifestPath: String;
  HostPath: String;
  Manifest: String;
begin
  if CurStep = ssPostInstall then
  begin
    ManifestDir := ExpandConstant('{localappdata}\SalesforceOrgLauncher\NativeMessagingHosts');
    ManifestPath := ManifestDir + '\com.kiran.salesforce_org_launcher.json';
    HostPath := ExpandConstant('{localappdata}\Salesforce CLI Org Launcher\native-host\native-launcher.exe');
    ForceDirectories(ManifestDir);

    Manifest :=
      '{' + #13#10 +
      '  "name": "com.kiran.salesforce_org_launcher",' + #13#10 +
      '  "description": "Salesforce CLI Org Launcher native host",' + #13#10 +
      '  "path": "' + JsonEscape(HostPath) + '",' + #13#10 +
      '  "type": "stdio",' + #13#10 +
      '  "allowed_origins": [' + #13#10 +
      '    "chrome-extension://kanjinfiojebibldeeajnbmgjmdipjjn/"' + ',' + #13#10 +
      '    "chrome-extension://nmjgfcdchchicaophfglfeijceibpkde/"' + ',' + #13#10 +
      '    "chrome-extension://aigfbbnieiipffbjinoccnbocfhlkepm/"' + #13#10 +
      '  ]' + #13#10 +
      '}' + #13#10;

    SaveStringToFile(ManifestPath, Manifest, False);
  end;
end;
