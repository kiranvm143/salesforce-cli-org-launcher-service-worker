param(
  [string]$ExtensionIds = "kanjinfiojebibldeeajnbmgjmdipjjn,nmjgfcdchchicaophfglfeijceibpkde,aigfbbnieiipffbjinoccnbocfhlkepm"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:CHROME_EXTENSION_IDS = $ExtensionIds
node scripts/install-native-host.mjs windows
$HostCmd = Join-Path $env:LOCALAPPDATA "Salesforce CLI Org Launcher\native-host\native-launcher.exe"
$LogDir = Join-Path $env:USERPROFILE ".salesforce-org-launcher"
$RunnerLog = Join-Path $LogDir "host-runner.log"
$LauncherLog = Join-Path $LogDir "launcher.log"
Write-Host "Testing installed native host and Salesforce CLI detection..."
$SmokeOutput = (& $HostCmd --smoke 2>&1) | Out-String
if ($LASTEXITCODE -ne 0) {
  Write-Host $SmokeOutput
  throw "Native host smoke test failed. Check $RunnerLog and $LauncherLog"
}
Write-Host $SmokeOutput.Trim()
if ($SmokeOutput -notmatch '"installed":true') {
  throw "Salesforce CLI is still not visible to the native host. Open a new PowerShell and run 'where sf' and 'sf --version', then reinstall. Logs: $RunnerLog and $LauncherLog"
}
Write-Host "Native host installed for Windows."
Write-Host "Open the Chrome extension and click Refresh."
