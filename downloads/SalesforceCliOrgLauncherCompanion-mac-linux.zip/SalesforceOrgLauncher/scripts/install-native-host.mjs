import { chmod, cp, mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { execFile } from "node:child_process";
import os from "node:os";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const hostName = "com.kiran.salesforce_org_launcher";
const targetOsArg = process.argv[2];
const targetOs = normalizeTargetOs(targetOsArg ?? process.platform);
const defaultExtensionIds = [
  "kanjinfiojebibldeeajnbmgjmdipjjn",
  "nmjgfcdchchicaophfglfeijceibpkde",
  "aigfbbnieiipffbjinoccnbocfhlkepm"
];
const extensionIds = normalizeExtensionIds(process.env.CHROME_EXTENSION_IDS || process.env.CHROME_EXTENSION_ID || defaultExtensionIds.join(","));
const sourceManifest = path.join(root, "dist", "native-host", `${hostName}.json`);
const sourceRuntimeDir = path.join(root, "dist", "native-host");
const installedRuntimeDir = nativeHostInstallDir();

function normalizeExtensionIds(value) {
  const ids = value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  return [...new Set(ids)];
}

function nativeHostInstallDir() {
  if (targetOs === "mac") {
    return path.join(os.homedir(), "Library", "Application Support", "Salesforce CLI Org Launcher", "native-host");
  }
  if (targetOs === "linux") {
    return path.join(os.homedir(), ".local", "share", "salesforce-cli-org-launcher", "native-host");
  }
  if (targetOs === "windows") {
    const base = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
    return path.join(base, "Salesforce CLI Org Launcher", "native-host");
  }
  return sourceRuntimeDir;
}

function normalizeTargetOs(value) {
  const normalized = value.toLowerCase();
  if (["darwin", "mac", "macos"].includes(normalized)) {
    return "mac";
  }
  if (["win32", "windows", "win"].includes(normalized)) {
    return "windows";
  }
  if (["linux"].includes(normalized)) {
    return "linux";
  }
  return normalized;
}

function nativeHostExecutable() {
  if (targetOs === "windows") {
    return path.join(installedRuntimeDir, "native-launcher.exe");
  }
  if (targetOs === "mac") {
    return path.join(installedRuntimeDir, "native-launcher");
  }
  return path.join(installedRuntimeDir, "run-host.sh");
}

function manifestInstallTargets() {
  if (targetOs === "mac") {
    return [
      path.join(os.homedir(), "Library", "Application Support", "Google", "Chrome", "NativeMessagingHosts", `${hostName}.json`),
      path.join(os.homedir(), "Library", "Application Support", "Chromium", "NativeMessagingHosts", `${hostName}.json`)
    ];
  }

  if (targetOs === "linux") {
    return [
      path.join(os.homedir(), ".config", "google-chrome", "NativeMessagingHosts", `${hostName}.json`),
      path.join(os.homedir(), ".config", "chromium", "NativeMessagingHosts", `${hostName}.json`)
    ];
  }

  if (targetOs === "windows") {
    const base = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
    return [path.join(base, "SalesforceOrgLauncher", "NativeMessagingHosts", `${hostName}.json`)];
  }

  throw new Error("Usage: node scripts/install-native-host.mjs <mac|linux|windows>");
}

async function writeManifest(targetPath) {
  const manifest = JSON.parse(await readFile(sourceManifest, "utf8"));
  manifest.path = nativeHostExecutable();
  manifest.allowed_origins = extensionIds.map((extensionId) => `chrome-extension://${extensionId}/`);
  await mkdir(path.dirname(targetPath), { recursive: true });
  await writeFile(targetPath, JSON.stringify(manifest, null, 2), "utf8");
  return targetPath;
}

async function chmodIfPresent(filePath) {
  try {
    await chmod(filePath, 0o755);
  } catch {
    // Windows and some release bundles do not include every launcher variant.
  }
}

async function writeNodePathHint() {
  await writeFile(path.join(installedRuntimeDir, "node-path.txt"), process.execPath, "utf8");
}

async function writePathSnapshot() {
  await writeFile(path.join(installedRuntimeDir, "path-snapshot.txt"), process.env.PATH || "", "utf8");
}

async function ensureWindowsNativeLauncher() {
  if (targetOs !== "windows") {
    return;
  }

  const launcherPath = path.join(installedRuntimeDir, "native-launcher.exe");
  const launcherSourcePath = path.join(installedRuntimeDir, "windows-launcher.go");

  try {
    await stat(launcherPath);
    return;
  } catch {
    // Older or source-only packages can still self-heal when Go is available.
  }

  try {
    await execFileAsync("go", ["build", "-trimpath", "-ldflags", "-s -w", "-o", launcherPath, launcherSourcePath], {
      cwd: installedRuntimeDir,
      env: {
        ...process.env,
        GOOS: "windows",
        GOARCH: "amd64",
        CGO_ENABLED: "0"
      }
    });
  } catch (error) {
    const detail = error.stderr || error.stdout || error.message;
    throw new Error(`Windows native launcher was not packaged and could not be built automatically. Install the latest companion package or install Go, then rerun this installer. ${detail}`);
  }
}

async function installNativeRuntime() {
  await rm(installedRuntimeDir, { recursive: true, force: true });
  await mkdir(installedRuntimeDir, { recursive: true });
  await cp(sourceRuntimeDir, installedRuntimeDir, { recursive: true });
}

async function installMacProfileManifests(manifest) {
  const chromeRoots = [
    path.join(os.homedir(), "Library", "Application Support", "Google", "Chrome"),
    path.join(os.homedir(), "Library", "Application Support", "Chromium")
  ];

  for (const chromeRoot of chromeRoots) {
    const entries = await readdir(chromeRoot).catch(() => []);
    for (const entry of entries) {
      const fullPath = path.join(chromeRoot, entry);
      const info = await stat(fullPath).catch(() => null);
      if (!info?.isDirectory() || (entry !== "Default" && !entry.startsWith("Profile "))) {
        continue;
      }

      const profileManifestTarget = path.join(fullPath, "NativeMessagingHosts", `${hostName}.json`);
      await mkdir(path.dirname(profileManifestTarget), { recursive: true });
      await writeFile(profileManifestTarget, JSON.stringify(manifest, null, 2), "utf8");
      console.log(`Installed profile native host manifest at ${profileManifestTarget}`);
    }
  }
}

async function installWindowsRegistry(manifestPath) {
  const key = `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${hostName}`;
  await execFileAsync("reg", ["add", key, "/ve", "/t", "REG_SZ", "/d", manifestPath, "/f"]);
  console.log(`Registered Windows native host registry key ${key}`);
}

await installNativeRuntime();
await chmodIfPresent(path.join(installedRuntimeDir, "index.js"));
await chmodIfPresent(path.join(installedRuntimeDir, "run-host.sh"));
await chmodIfPresent(path.join(installedRuntimeDir, "native-launcher"));
await writeNodePathHint();
await writePathSnapshot();
await ensureWindowsNativeLauncher();

const targets = manifestInstallTargets();
const installedTargets = [];
for (const target of targets) {
  installedTargets.push(await writeManifest(target));
  console.log(`Installed native host manifest at ${target}`);
}

const installedManifest = JSON.parse(await readFile(installedTargets[0], "utf8"));

if (targetOs === "mac") {
  await installMacProfileManifests(installedManifest);
}

if (targetOs === "windows") {
  await installWindowsRegistry(installedTargets[0]);
}

console.log(`Allowed extension origins: ${extensionIds.map((extensionId) => `chrome-extension://${extensionId}/`).join(", ")}`);
console.log(`Installed native host runtime at ${installedRuntimeDir}`);
