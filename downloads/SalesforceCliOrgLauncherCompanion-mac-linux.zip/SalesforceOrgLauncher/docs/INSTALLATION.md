# Installation Guide

## Build

```bash
cd /Users/kiranmarkad/Desktop/SalesforceOrgLauncher
npm install
npm run build
```

## Load the extension

1. Open Chrome and go to `chrome://extensions`
2. Turn on Developer mode
3. Choose Load unpacked
4. Select `/Users/kiranmarkad/Desktop/SalesforceOrgLauncher/dist/extension`

If Chrome selects the parent folder from Finder, `/Users/kiranmarkad/Desktop/SalesforceOrgLauncher/dist` also works.

## Register the native host on macOS

1. Copy the extension ID shown on the extension card
2. Run:

```bash
cd /Users/kiranmarkad/Desktop/SalesforceOrgLauncher
CHROME_EXTENSION_ID=<extension-id> npm run install:native:mac
```

## Create a portable package

```bash
cd /Users/kiranmarkad/Desktop/SalesforceOrgLauncher
npm run package
```

Share this file:

```text
/Users/kiranmarkad/Desktop/SalesforceOrgLauncher/release/SalesforceOrgLauncher-portable-mac-windows-linux.zip
```

Upload this file to Chrome Web Store:

```text
/Users/kiranmarkad/Desktop/SalesforceOrgLauncher/release/SalesforceOrgLauncher-chrome-web-store.zip
```

Build this Windows installer source on a Windows machine with Inno Setup 6:

```text
/Users/kiranmarkad/Desktop/SalesforceOrgLauncher/release/SalesforceOrgLauncher-windows-installer-source.zip
```

The Windows installer output is:

```text
SalesforceCliOrgLauncherCompanionSetup.exe
```

On the target machine:

1. Unzip the package.
2. Load the `extension` folder from `chrome://extensions` with Developer mode enabled.
3. Run `./install-mac-linux.sh` on macOS/Linux or `powershell -ExecutionPolicy Bypass -File .\install-windows.ps1` on Windows.

The companion installer copies the native host into the user's app-data folder before registering it with Chrome, so the extension does not depend on the unzipped package staying on Desktop or Downloads.

On macOS, protected folders such as Desktop, Documents, and Downloads can still trigger an Apple privacy prompt when they are configured as project roots. The popup avoids repeated prompts by loading cached org data on open and only rescanning folders after **Refresh** or settings changes.

## Verify

1. Open the extension popup
2. Click Refresh
3. Confirm CLI detection succeeds
4. Confirm projects and orgs appear grouped
5. Open an org and verify a new tab launches
