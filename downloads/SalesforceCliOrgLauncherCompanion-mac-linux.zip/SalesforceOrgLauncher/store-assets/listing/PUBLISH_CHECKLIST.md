# Publish Checklist

## Before Upload

- Run `npm run lint`.
- Run `npm run test:popup`.
- Run `npm run test:smoke`.
- Run `CHROME_EXTENSION_ID=<web-store-extension-id> npm run package`.
- Confirm `release/SalesforceOrgLauncher-chrome-web-store.zip` exists.
- Confirm `release/SalesforceOrgLauncher-windows-installer-source.zip` exists for Windows companion installer builds.
- Confirm screenshots exist under `store-assets/screenshots`.

## Chrome Web Store Dashboard

- Upload `release/SalesforceOrgLauncher-chrome-web-store.zip`.
- Set category to Developer Tools.
- Add the short description from `CHROME_WEB_STORE_LISTING.md`.
- Add the detailed description from `CHROME_WEB_STORE_LISTING.md`.
- Upload screenshots from `store-assets/screenshots`.
- Upload or reference the 128px icon from `dist/extension/icons/icon128.png`.
- Add the public privacy policy URL:
  `https://kiranvm143.github.io/salesforce-cli-org-launcher-service-worker/docs/privacy-policy.html`
- Complete privacy practices using `store-assets/privacy/PRIVACY_PRACTICES_DISCLOSURE.md`.
- Add reviewer notes from `store-assets/listing/REVIEWER_NOTES.md`.

## After First Web Store Upload

- Copy the final Chrome Web Store extension ID.
- Rebuild packages with `CHROME_EXTENSION_ID=<web-store-extension-id> npm run package`.
- Build the Windows companion installer on Windows from `release/SalesforceOrgLauncher-windows-installer-source.zip`.
- Distribute the macOS/Linux/Windows companion installer links from the extension support or onboarding page.

## Final Manual Smoke Test

- Install the Chrome Web Store build or load the generated webstore ZIP in a clean Chrome profile.
- Install the companion native host.
- Open the popup.
- Confirm CLI detected.
- Click Refresh.
- Confirm favorites persist.
- Create a custom group.
- Confirm the group appears immediately.
- Delete the group.
- Confirm the group disappears immediately.
- Click Open on a valid org.
- Click Open on an expired org if available and confirm the extension shows a reauthorization error.
