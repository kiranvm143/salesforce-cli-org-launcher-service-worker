# Chrome Web Store Reviewer Notes

Salesforce CLI Org Launcher is a Manifest V3 developer tool extension.

## Purpose

The extension lists Salesforce CLI authenticated orgs from the user's local machine and lets the user open a selected org.

## Why Native Messaging Is Required

Chrome extensions cannot directly execute Salesforce CLI commands. The extension uses Chrome Native Messaging to communicate with a local companion host that runs Salesforce CLI commands on the user's machine.

The companion host is installed separately because Chrome Web Store extensions are not allowed to silently install native messaging hosts.

## Permissions

The extension requests only:

- `storage`
- `nativeMessaging`

The extension does not request host permissions such as `<all_urls>` and does not read or modify websites.

## Test Setup

To fully test the extension:

1. Install Salesforce CLI.
2. Authenticate at least one Salesforce org using Salesforce CLI.
3. Install the companion native host for the platform.
4. Open the extension popup.
5. Click Refresh.
6. Click Open on an available org.

If Salesforce CLI or the companion host is not installed, the popup displays setup guidance instead of failing silently.

## Web Store Package

Upload:

`release/SalesforceOrgLauncher-chrome-web-store.zip`

Do not upload the companion installer ZIP to Chrome Web Store.
