# Chrome Web Store Listing

## Extension Name

Salesforce CLI Org Launcher

## Short Description

Launch Salesforce CLI authenticated orgs from a polished project-first Chrome extension.

## Detailed Description

Salesforce CLI Org Launcher helps Salesforce developers, admins, and consultants open the right Salesforce org quickly from Chrome with a focused, local-first launcher.

Instead of hunting through terminal commands or long org lists, the extension reads your locally authenticated Salesforce CLI orgs through a native companion app and presents them in a polished launcher grouped around projects, favorites, and custom org groups.

Key features:

- Open Salesforce CLI authenticated orgs directly from Chrome.
- Search org aliases, usernames, project names, instance URLs, and org IDs.
- Save favorite orgs for faster access.
- Create custom org groups that stay available the next time you open the extension.
- Configure project roots, theme, auto-refresh behavior, and cache duration.
- Works with modern Salesforce CLI setups using `sf` or `sfdx`.
- Shows clear setup and reauthorization guidance when the CLI or an org session needs attention.
- Includes OS-aware companion setup guidance for macOS, Windows, and Linux, including a one-click Windows companion installer.
- Uses a compact, cleaner footer and status display so the popup stays readable in the Chrome extension window.

Important setup note:

Chrome Web Store installs the browser extension. Local Salesforce CLI access requires the Salesforce CLI Org Launcher companion native host to be installed once per machine. This is required by Chrome's native messaging security model and lets the extension communicate with Salesforce CLI on your computer.

Most users can install the companion with one command:

`npx --yes github:kiranvm143/salesforce-cli-org-launcher-service-worker install`

The command detects macOS, Windows, or Linux and installs the correct companion package.

Requirements:

- Google Chrome or Chromium.
- Salesforce CLI installed and authenticated.
- Node.js 20+ for the companion host.
- Companion native host installer for macOS, Windows, or Linux.

Created by:

Crafted with ❤️ by Kiran Markad.

## Category

Developer Tools

## Language

English

## Single Purpose Statement

Salesforce CLI Org Launcher provides a browser popup that lists locally authenticated Salesforce CLI orgs and opens the selected org through Salesforce CLI.

## Permission Justification

`storage`:

Used to save user preferences locally, including favorites, expanded groups, custom org groups, theme, cache duration, and configured project roots.

`nativeMessaging`:

Used to communicate with the installed local companion native host. The native host runs Salesforce CLI commands such as org listing and org open URL generation on the user's machine.

## Remote Code

The extension does not load or execute remote code. All extension JavaScript is bundled inside the submitted Chrome Web Store package.

## Data Usage Summary

The extension uses local Chrome extension storage for preferences and cached org metadata. It does not sell data, does not use ads, and does not send org data to third-party analytics services.

## Homepage URL

https://kiranvm143.github.io/salesforce-cli-org-launcher-service-worker/

## Support URL

https://github.com/kiranvm143/salesforce-cli-org-launcher-service-worker

## Privacy Policy URL

https://kiranvm143.github.io/salesforce-cli-org-launcher-service-worker/docs/privacy-policy.html
