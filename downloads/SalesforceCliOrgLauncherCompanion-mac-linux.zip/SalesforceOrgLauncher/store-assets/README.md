# Web Store Submission Assets

This folder contains Chrome Web Store dashboard materials for Salesforce CLI Org Launcher.

## Upload Package

Upload this ZIP as the extension package:

`release/SalesforceOrgLauncher-chrome-web-store.zip`

## Listing Assets

Use these files in the Chrome Web Store Developer Dashboard:

- `screenshots/*-1280x800.png`: Five upload-ready screenshots.
- `promo/small-promo-440x280.png`: Small promotional tile.
- `promo/marquee-promo-1400x560.png`: Optional marquee promotional tile.
- `listing/CHROME_WEB_STORE_LISTING.md`: Short description, detailed description, single-purpose statement, and permission justifications.
- `listing/REVIEWER_NOTES.md`: Reviewer notes for native messaging and local companion setup.
- `listing/PUBLISH_CHECKLIST.md`: Step-by-step publish checklist.
- `privacy/PRIVACY_POLICY.md`: Markdown privacy policy source.
- `privacy/privacy-policy.html`: Hostable privacy policy page.
- `privacy/PRIVACY_PRACTICES_DISCLOSURE.md`: Working notes for the dashboard privacy form.

## Companion Installer

The Chrome Web Store ZIP contains only the browser extension. The companion native host must be distributed separately for macOS, Windows, and Linux.

Chrome requires this split because native messaging hosts are installed and registered at the operating-system level.
