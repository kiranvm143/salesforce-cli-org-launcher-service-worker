# Chrome Web Store Privacy Practices Disclosure

Use this as the working reference when completing the Chrome Web Store Developer Dashboard privacy form.

Public privacy policy URL:

```text
https://kiranvm143.github.io/salesforce-cli-org-launcher-service-worker/docs/privacy-policy.html
```

## Data Collection

Recommended selection:

The extension does not collect user data for transfer to the publisher or third parties.

Reason:

Org metadata and preferences are stored locally on the user's machine. The extension does not send this data to external analytics, advertising, or publisher-operated services.

## Data Categories

If the dashboard requires disclosure for locally handled data, document that the extension locally handles:

- Authentication information: Salesforce CLI authenticated org references may be used locally by Salesforce CLI, but the extension does not collect Salesforce passwords or tokens.
- Website content: Not collected. The extension does not request host permissions and does not read website page content.
- Personally identifiable information: Salesforce usernames may be displayed from local Salesforce CLI output and cached locally.

## Limited Use

The extension uses data only for its single purpose: listing and opening locally authenticated Salesforce CLI orgs.

## Certification Notes

- No ads.
- No analytics.
- No sale of data.
- No remote code execution.
- No broad host permissions.
- Native messaging is used only for local Salesforce CLI access.
