// extension/src/popup.ts
var DEFAULT_SETTINGS = {
  roots: ["~/Projects", "~/Development", "~/workspace", "~/Documents"],
  theme: "system",
  autoRefresh: true,
  cacheDurationMinutes: 15
};
var APP_VERSION = "0.1.19";
var HOST_NAME = "com.kiran.salesforce_org_launcher";
var HANDLED_ACTION_WINDOW_MS = 1500;
var SUPPORT_SITE_URL = "https://kiranvm143.github.io/salesforce-cli-org-launcher-service-worker/";
var INSTALL_GUIDE_URL = "https://kiranvm143.github.io/salesforce-cli-org-launcher-service-worker/docs/INSTALL_AND_CONNECT.md";
var GITHUB_REPO_URL = "https://github.com/kiranvm143/salesforce-cli-org-launcher-service-worker";
var MAC_LINUX_DOWNLOAD_URL = `${SUPPORT_SITE_URL}downloads/SalesforceCliOrgLauncherCompanion-mac-linux.zip`;
var WINDOWS_DOWNLOAD_URL = `${SUPPORT_SITE_URL}downloads/SalesforceCliOrgLauncherCompanionSetup.exe`;
var NPM_INSTALL_COMMAND = "npx --yes github:kiranvm143/salesforce-cli-org-launcher-service-worker install";
var state = {
  data: null,
  cliInfo: null,
  settings: DEFAULT_SETTINGS,
  favorites: [],
  orgGroups: [],
  orgStatuses: {},
  expandedGroups: [],
  expandedProjects: [],
  searchQuery: "",
  loading: false,
  statusRefreshing: false,
  authPanelOpen: false,
  authEnvironment: "production"
};
var lastActionKey = "";
var lastActionAt = 0;
var settingsOpen = false;
var pendingRemoveOrgKey = "";
function getLocalStorage(keys) {
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      reject(new Error("Chrome storage did not respond. Reload the extension and try again."));
    }, 5e3);
    chrome.storage.local.get(keys, (items) => {
      window.clearTimeout(timer);
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(items);
    });
  });
}
function setLocalStorage(values) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(values, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve();
    });
  });
}
function sendMessage(message, timeoutMs = 3e4) {
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      reject(new Error("The extension service worker did not respond. Reload the extension and try again."));
    }, timeoutMs);
    chrome.runtime.sendMessage(message, (response) => {
      window.clearTimeout(timer);
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(response);
    });
  });
}
function sendNativeMessage(message, timeoutMs = 3e4) {
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      reject(new Error("Native host did not respond. Reinstall the companion native host, then reload the extension."));
    }, timeoutMs);
    chrome.runtime.sendNativeMessage(HOST_NAME, message, (response) => {
      window.clearTimeout(timer);
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(response);
    });
  });
}
function openTab(url) {
  return new Promise((resolve, reject) => {
    chrome.tabs.create({ url }, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve();
    });
  });
}
async function loadBootstrapState() {
  render();
  const storage = await getLocalStorage(["favorites", "expandedProjects", "orgGroups", "expandedGroups", "settings", "cache", "orgStatusCache"]);
  state.favorites = Array.isArray(storage.favorites) ? storage.favorites : [];
  state.expandedProjects = Array.isArray(storage.expandedProjects) ? storage.expandedProjects : [];
  state.orgGroups = Array.isArray(storage.orgGroups) ? storage.orgGroups : [];
  state.expandedGroups = Array.isArray(storage.expandedGroups) ? storage.expandedGroups : state.orgGroups.map((group) => group.id);
  state.settings = isLauncherSettings(storage.settings) ? storage.settings : DEFAULT_SETTINGS;
  applyTheme(state.settings.theme);
  applyCachedData(storage.cache);
  applyStatusCache(storage.orgStatusCache);
  state.loading = false;
  render();
  void warmNativeData();
}
function isLauncherSettings(value) {
  const candidate = value;
  return Boolean(
    candidate && Array.isArray(candidate.roots) && typeof candidate.theme === "string" && typeof candidate.autoRefresh === "boolean" && typeof candidate.cacheDurationMinutes === "number"
  );
}
function applyCachedData(value) {
  const cache = value;
  if (cache?.payload) {
    state.data = cache.payload;
    state.cliInfo = cache.payload.cliInfo;
    state.lastRefresh = cache.payload.generatedAt;
    if (state.expandedProjects.length === 0) {
      state.expandedProjects = cache.payload.projects.map((project) => project.name);
    }
    return true;
  }
  return false;
}
function applyStatusCache(value) {
  const cache = value;
  if (cache?.statuses && typeof cache.statuses === "object") {
    state.orgStatuses = cache.statuses;
    return true;
  }
  return false;
}
async function warmNativeData() {
  try {
    await wakeServiceWorker();
    await detectCli();
    if (state.data?.cliInfo.installed) {
      void refreshOrgStatuses(false);
    }
  } finally {
    render();
  }
}
async function wakeServiceWorker() {
  await sendMessage({ type: "ping" }, 2e3);
}
async function detectCli() {
  try {
    const result = await sendMessage({ type: "detectCli" }, 12e3);
    if (!result.ok) {
      throw new Error(result.error ?? "Unable to detect Salesforce CLI.");
    }
    state.cliInfo = result.cliInfo;
  } catch (error) {
    state.cliInfo = { installed: false, error: error instanceof Error ? error.message : String(error) };
  }
}
async function refreshData(forceRefresh = false) {
  state.loading = true;
  render();
  try {
    const result = await sendMessage({
      type: "getData",
      forceRefresh
    });
    if (!result.ok) {
      throw new Error(result.error ?? "Unable to load orgs.");
    }
    state.data = result.payload;
    state.cliInfo = result.payload.cliInfo;
    state.lastRefresh = result.payload.generatedAt;
    state.error = void 0;
    state.statusMessage = void 0;
    if (state.expandedProjects.length === 0) {
      state.expandedProjects = result.payload.projects.map((project) => project.name);
    }
    if (result.payload.cliInfo.installed) {
      void refreshOrgStatuses(forceRefresh);
    }
  } catch (error) {
    state.error = error instanceof Error ? error.message : String(error);
  } finally {
    state.loading = false;
    render();
  }
}
async function refreshOrgStatuses(forceRefresh = false) {
  if (state.statusRefreshing) {
    return;
  }
  state.statusRefreshing = true;
  state.statusMessage = "Checking org status...";
  render();
  try {
    const result = await sendMessage({ type: "refreshOrgStatuses", forceRefresh }, 125e3);
    if (!result.ok) {
      if (result.statuses) {
        state.orgStatuses = result.statuses;
      }
      throw new Error(result.error ?? "Unable to refresh org statuses.");
    }
    state.orgStatuses = result.statuses;
    state.statusMessage = result.cached ? "Org status up to date" : `Org status updated ${formatDate(result.fetchedAt)}`;
  } catch (error) {
    state.statusMessage = "Could not refresh org status";
    console.warn(error);
  } finally {
    state.statusRefreshing = false;
    render();
  }
}
function escapeHtml(value) {
  return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}
function applyTheme(theme) {
  const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
  const resolved = theme === "system" ? prefersDark ? "dark" : "light" : theme;
  document.documentElement.dataset.theme = resolved;
}
function formatDate(value) {
  if (!value) {
    return "Unknown";
  }
  const date = new Date(value);
  return new Intl.DateTimeFormat(void 0, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit"
  }).format(date);
}
function formatCliVersion(version) {
  if (!version) {
    return { version: "Version unknown", platform: "", node: "" };
  }
  const normalized = version.replace(/^@salesforce\/cli\//, "").trim();
  const parts = normalized.split(/\s+/).filter(Boolean);
  const [cliVersion = normalized, platform = "", node = ""] = parts;
  return {
    version: `v${cliVersion.replace(/^v/, "")}`,
    platform,
    node: node.replace(/^node-?/, "Node ")
  };
}
function renderCliStatus(cliInfo) {
  if (!cliInfo) {
    return `
      <span class="cli-pill cli-pill-checking">
        <span class="cli-dot"></span>
        <span>
          <strong>Checking Salesforce CLI</strong>
          <small>Waiting for companion host</small>
        </span>
      </span>
    `;
  }
  if (!cliInfo.installed) {
    return `
      <span class="cli-pill cli-pill-error">
        <span class="cli-dot"></span>
        <span>
          <strong>CLI not detected</strong>
          <small>Install companion host to continue</small>
        </span>
      </span>
    `;
  }
  const details = formatCliVersion(cliInfo.version);
  return `
    <span class="cli-pill">
      <span class="cli-dot"></span>
      <span>
        <strong>${escapeHtml(cliInfo.cli ?? "sf")} ${escapeHtml(details.version)}</strong>
        <small>${escapeHtml([details.platform, details.node].filter(Boolean).join(" \xB7 "))}</small>
      </span>
    </span>
  `;
}
function nativeHostSetupNeeded() {
  const message = `${state.error ?? ""} ${state.cliInfo?.error ?? ""}`.toLowerCase();
  return [
    "native host",
    "native messaging host",
    "specified native messaging host not found",
    "host has exited",
    "failed to connect"
  ].some((pattern) => message.includes(pattern));
}
function installerCommand() {
  return NPM_INSTALL_COMMAND;
}
function currentPlatformId() {
  const platform = navigator.userAgent.toLowerCase();
  if (platform.includes("windows")) {
    return "windows";
  }
  if (platform.includes("linux")) {
    return "linux";
  }
  return "mac";
}
function getSetupOptions() {
  return [
    {
      id: "mac",
      label: "macOS",
      downloadUrl: MAC_LINUX_DOWNLOAD_URL,
      command: NPM_INSTALL_COMMAND
    },
    {
      id: "windows",
      label: "Windows",
      downloadUrl: WINDOWS_DOWNLOAD_URL,
      command: NPM_INSTALL_COMMAND
    },
    {
      id: "linux",
      label: "Linux",
      downloadUrl: MAC_LINUX_DOWNLOAD_URL,
      command: NPM_INSTALL_COMMAND
    }
  ];
}
function renderSetupOption(option, currentPlatform) {
  return `
    <article class="setup-os-card ${option.id === currentPlatform ? "setup-os-card-active" : ""}">
      <div class="setup-os-row">
        <strong>${escapeHtml(option.label)}</strong>
        ${option.id === currentPlatform ? '<span class="badge badge-default">This device</span>' : ""}
      </div>
      <div class="setup-os-actions">
        <button type="button" class="secondary-button" data-action="openExternal" data-value="${escapeHtml(option.downloadUrl)}">Download</button>
        <button type="button" class="ghost-button" data-action="copySetupCommand" data-value="${escapeHtml(option.command)}">Copy Command</button>
      </div>
    </article>
  `;
}
function renderSetupPanel() {
  const command = installerCommand();
  const currentPlatform = currentPlatformId();
  const setupOptions = getSetupOptions();
  return `
    <section class="setup-panel">
      <div class="setup-kicker">Companion setup needed</div>
      <h2>Finish native host install</h2>
      <p>
        Chrome installed the extension, but Chrome does not allow extensions to silently install local native messaging hosts.
        Run the companion installer once with Node.js, then click Refresh.
      </p>
      <div class="setup-link-grid">
        <button type="button" class="icon-button" data-action="openExternal" data-value="${escapeHtml(INSTALL_GUIDE_URL)}">Open Install Guide</button>
        <button type="button" class="icon-button" data-action="openExternal" data-value="${escapeHtml(GITHUB_REPO_URL)}">GitHub</button>
        <button type="button" class="icon-button" data-action="openExternal" data-value="${escapeHtml(SUPPORT_SITE_URL)}">Support Page</button>
        <button type="button" class="primary-button" data-action="copySetupCommand" data-value="${escapeHtml(command)}">Copy Command For This Device</button>
      </div>
      <div class="setup-os-grid">${setupOptions.map((option) => renderSetupOption(option, currentPlatform)).join("")}</div>
      <div class="setup-steps">
        <span>1. Install Node.js and Salesforce CLI if they are not already installed.</span>
        <span>2. Run this one command. It detects macOS, Windows, or Linux and installs the right companion package.</span>
        <span>3. Use the OS download buttons only if you prefer manual install.</span>
      </div>
      <code class="setup-command">${escapeHtml(command)}</code>
      <div class="setup-actions">
        <button type="button" class="icon-button" data-action="refresh">Check Again</button>
      </div>
    </section>
  `;
}
function favoriteRank(org) {
  return state.favorites.includes(orgKey(org)) ? 0 : 1;
}
function orgKey(org) {
  return org.alias || org.username;
}
function statusLookupKeys(org) {
  return [orgKey(org), org.alias, org.username, org.orgId].map((value) => String(value || "").toLowerCase()).filter(Boolean);
}
function getOrgStatus(org) {
  for (const key of statusLookupKeys(org)) {
    const status = state.orgStatuses[key];
    if (status) {
      return status;
    }
  }
  return void 0;
}
function getOrgConnectionStatus(org) {
  return getOrgStatus(org)?.connectionStatus ?? (state.statusRefreshing ? "checking" : "unknown");
}
function getOrgStatusLabel(org) {
  return getOrgStatus(org)?.statusLabel ?? (state.statusRefreshing ? "Checking status" : "Status unknown");
}
function canOpenOrg(org) {
  const status = getOrgConnectionStatus(org);
  return Boolean(orgKey(org)) && status !== "expired" && status !== "unreachable";
}
function canReauthorizeOrg(org) {
  return Boolean(org.alias || org.username);
}
function friendlyStatusHelp(status) {
  if (status === "expired") {
    return "Your Salesforce session expired. Sign in again to reconnect this org.";
  }
  if (status === "unreachable") {
    return "Salesforce could not reach this org right now.";
  }
  return "";
}
function matchesSearch(org, projectName = "") {
  const query = state.searchQuery.trim().toLowerCase();
  if (!query) {
    return true;
  }
  return [org.alias, org.username, org.orgId, org.instanceUrl, projectName].some(
    (item) => item?.toLowerCase().includes(query)
  );
}
function getProjectList() {
  if (!state.data) {
    return [];
  }
  return state.data.projects.map((project) => ({
    ...project,
    orgs: [...project.orgs].filter((org) => matchesSearch(org, project.name)).sort((left, right) => favoriteRank(left) - favoriteRank(right) || left.alias.localeCompare(right.alias))
  })).filter((project) => project.orgs.length > 0 || project.name.toLowerCase().includes(state.searchQuery.toLowerCase()));
}
function getOtherOrgs() {
  if (!state.data) {
    return [];
  }
  return [...state.data.others].filter((org) => matchesSearch(org, "Other Authenticated Orgs")).sort((left, right) => favoriteRank(left) - favoriteRank(right) || left.alias.localeCompare(right.alias));
}
function getAllOrgs() {
  if (!state.data) {
    return [];
  }
  return [
    ...state.data.projects.flatMap((project) => project.orgs),
    ...state.data.others
  ];
}
function findOrgByKey(key) {
  return getAllOrgs().find((org) => orgKey(org) === key);
}
function groupContainsOrg(group, key) {
  return group.orgKeys.includes(key);
}
function renderBadge(label, tone) {
  return `<span class="badge badge-${tone}">${escapeHtml(label)}</span>`;
}
function renderStatusBadge(status, label) {
  return `<span class="status-badge status-${status}">${escapeHtml(label)}</span>`;
}
function instanceUrlForEnvironment(environment) {
  if (environment === "sandbox") {
    return "https://test.salesforce.com";
  }
  if (environment === "production") {
    return "https://login.salesforce.com";
  }
  return "";
}
function renderAuthNewOrgPanel() {
  const selected = state.authEnvironment ?? "production";
  return `
    <section class="auth-new-panel" ${state.authPanelOpen ? "" : "hidden"}>
      <div class="auth-panel-copy">
        <div class="setup-kicker">Connect another org</div>
        <h2>Authorize a new Salesforce org</h2>
        <p>Choose the login type, optionally add an alias, then complete Salesforce CLI web login in Chrome.</p>
      </div>
      <div class="auth-choice-grid" role="radiogroup" aria-label="Salesforce login type">
        ${[
    ["production", "Production", "login.salesforce.com"],
    ["sandbox", "Sandbox", "test.salesforce.com"],
    ["custom", "Custom URL", "My Domain or Experience URL"]
  ].map(([value, label, hint]) => `
          <label class="auth-choice-card ${selected === value ? "auth-choice-card-active" : ""}">
            <input type="radio" name="authEnvironment" value="${value}" ${selected === value ? "checked" : ""} data-action="selectAuthEnvironment" data-value="${value}" />
            <span>
              <strong>${label}</strong>
              <small>${hint}</small>
            </span>
          </label>
        `).join("")}
      </div>
      <div class="auth-form-grid">
        <label>
          <span>Alias optional</span>
          <input id="newOrgAlias" placeholder="e.g. qa-sandbox, client-prod" />
        </label>
        <label>
          <span>Custom login URL</span>
          <input id="customInstanceUrl" placeholder="https://your-domain.my.salesforce.com" ${selected === "custom" ? "" : "disabled"} />
        </label>
      </div>
      <div class="auth-panel-actions">
        <button type="button" class="primary-button" data-action="authorizeNewOrg">Start Web Auth</button>
        <button type="button" class="ghost-button" data-action="toggleAuthPanel">Cancel</button>
      </div>
    </section>
  `;
}
function renderGroupPicker(targetOrg) {
  if (state.orgGroups.length === 0 || !targetOrg) {
    return "";
  }
  return `
    <select class="group-select" data-org-key="${escapeHtml(targetOrg)}" aria-label="Choose group">
      ${state.orgGroups.map((group) => `<option value="${escapeHtml(group.id)}">${escapeHtml(group.name)}</option>`).join("")}
    </select>
    <button type="button" data-action="addToSelectedGroup" data-value="${escapeHtml(targetOrg)}">Add</button>
  `;
}
function renderOrgCard(org, groupId) {
  const targetOrg = orgKey(org);
  const favoriteKey = targetOrg;
  const favorite = state.favorites.includes(favoriteKey);
  const connectionStatus = getOrgConnectionStatus(org);
  const statusLabel = getOrgStatusLabel(org);
  const canOpen = canOpenOrg(org);
  const statusHelp = friendlyStatusHelp(connectionStatus);
  const shouldShowReauth = (connectionStatus === "expired" || connectionStatus === "unreachable") && canReauthorizeOrg(org);
  const removeConfirmOpen = pendingRemoveOrgKey === targetOrg;
  const encodedOrg = encodeURIComponent(JSON.stringify({
    alias: org.alias,
    username: org.username,
    instanceUrl: org.instanceUrl
  }));
  return `
    <article class="org-card">
      <div class="org-card-top">
        <div>
          <div class="org-alias-row">
            <h3>${escapeHtml(org.alias || org.username)}</h3>
            ${favorite ? renderBadge("Favorite", "accent") : ""}
            ${org.isDefault ? renderBadge("Default", "default") : ""}
            ${org.isDevHub ? renderBadge("Dev Hub", "neutral") : ""}
            ${renderStatusBadge(connectionStatus, statusLabel)}
          </div>
          <p class="org-username">${escapeHtml(org.username || "Unknown username")}</p>
        </div>
        <button type="button" class="favorite-button" data-action="favorite" data-value="${escapeHtml(favoriteKey)}" aria-label="Favorite org">
          ${favorite ? "\u2605" : "\u2606"}
        </button>
      </div>

      <div class="org-meta">
        <span>${escapeHtml(org.instanceUrl || "No URL")}</span>
        <span>${escapeHtml(org.orgId || "No Org ID")}</span>
        <span>${org.isSandbox ? "Sandbox" : org.isScratch ? "Scratch" : "Production"}</span>
        <span>Last used ${escapeHtml(formatDate(org.lastUsed))}</span>
      </div>
      ${statusHelp ? `<div class="org-status-help">${escapeHtml(statusHelp)}</div>` : ""}

      <div class="org-actions">
        <button type="button" class="org-open-button" data-action="open" data-value="${escapeHtml(targetOrg)}" ${canOpen ? "" : "disabled"}>Open</button>
        <button type="button" class="secondary-button" data-action="openSetup" data-value="${escapeHtml(targetOrg)}" ${canOpen ? "" : "disabled"}>Open Setup</button>
        ${shouldShowReauth ? `<button type="button" class="secondary-button" data-action="reauthorizeOrg" data-value="${escapeHtml(encodedOrg)}">Authorize Again</button>` : ""}
        ${connectionStatus === "expired" || connectionStatus === "unreachable" || connectionStatus === "unknown" ? '<button type="button" class="ghost-button" data-action="checkStatus">Check Again</button>' : ""}
        <button type="button" class="org-copy-button" data-action="copyUsername" data-value="${escapeHtml(org.username)}">Copy Username</button>
        <button type="button" class="org-copy-button" data-action="copyOrgId" data-value="${escapeHtml(org.orgId)}">Copy Org ID</button>
        <button type="button" class="org-copy-button" data-action="copyUrl" data-value="${escapeHtml(org.instanceUrl)}">Copy URL</button>
        ${renderGroupPicker(targetOrg)}
        <button type="button" class="org-copy-button" data-action="createGroupForOrg" data-value="${escapeHtml(targetOrg)}">New Group</button>
        <button type="button" class="danger-button" data-action="askRemoveOrg" data-value="${escapeHtml(encodedOrg)}">Remove Org</button>
        ${groupId ? `<button type="button" class="danger-button" data-action="removeFromGroup" data-group-id="${escapeHtml(groupId)}" data-value="${escapeHtml(targetOrg)}">Remove from Group</button>` : ""}
      </div>
      ${removeConfirmOpen ? `
        <div class="remove-confirm-panel">
          <div>
            <strong>Remove from Salesforce CLI?</strong>
            <p>This only removes the local CLI authorization entry. It does not delete the Salesforce org.</p>
          </div>
          <div class="remove-confirm-actions">
            <button type="button" class="danger-button" data-action="confirmRemoveOrg" data-value="${escapeHtml(encodedOrg)}">Yes, Remove</button>
            <button type="button" class="ghost-button" data-action="cancelRemoveOrg">Cancel</button>
          </div>
        </div>
      ` : ""}
    </article>
  `;
}
function renderProject(project) {
  const expanded = state.expandedProjects.includes(project.name);
  return `
    <section class="project-panel">
      <button type="button" class="project-header" data-action="toggleProject" data-value="${escapeHtml(project.name)}">
        <span class="project-toggle">${expanded ? "\u25BC" : "\u25B6"}</span>
        <span class="project-title-block">
          <strong>${escapeHtml(project.name)}</strong>
          <small>${escapeHtml(project.path)}</small>
        </span>
        <span class="project-count">${project.orgs.length}</span>
      </button>
      ${expanded ? `<div class="project-orgs">${project.orgs.map(renderOrgCard).join("")}</div>` : ""}
    </section>
  `;
}
function renderGroupBuilder() {
  return `
    <section class="group-builder-panel settings-group-builder">
      <div>
        <div class="setup-kicker">My org groups</div>
        <h2>Organize your launchpad</h2>
        <p>Create your own groups, then add any org from its card. Groups are saved locally and come back next time.</p>
      </div>
      <div class="group-create-row">
        <input id="newGroupName" placeholder="Group name, e.g. Daily QA, Client demos, Production" />
        <button type="button" class="primary-button" data-action="createGroup">Create Group</button>
      </div>
    </section>
  `;
}
function renderCustomGroup(group) {
  const expanded = state.expandedGroups.includes(group.id);
  const orgs = group.orgKeys.map(findOrgByKey).filter((org) => Boolean(org));
  const missingCount = group.orgKeys.length - orgs.length;
  const visibleOrgs = orgs.filter((org) => matchesSearch(org, group.name)).sort((left, right) => favoriteRank(left) - favoriteRank(right) || orgKey(left).localeCompare(orgKey(right)));
  return `
    <section class="project-panel group-panel">
      <button type="button" class="project-header" data-action="toggleGroup" data-value="${escapeHtml(group.id)}">
        <span class="project-toggle">${expanded ? "\u25BC" : "\u25B6"}</span>
        <span class="project-title-block">
          <strong>${escapeHtml(group.name)}</strong>
          <small>${missingCount > 0 ? `${missingCount} saved org${missingCount === 1 ? "" : "s"} not in current CLI data` : "Custom saved group"}</small>
        </span>
        <span class="project-count">${group.orgKeys.length}</span>
      </button>
      ${expanded ? `
        <div class="group-toolbar">
          <button type="button" class="danger-button" data-action="deleteGroup" data-value="${escapeHtml(group.id)}">Delete Group</button>
        </div>
        <div class="project-orgs">
          ${visibleOrgs.map((org) => renderOrgCard(org, group.id)).join("")}
          ${visibleOrgs.length === 0 ? '<div class="empty-state">No saved orgs in this group match the current search.</div>' : ""}
        </div>
      ` : ""}
    </section>
  `;
}
function renderOtherOrgsSection(orgs) {
  return `
    <section class="project-panel">
      <div class="project-header project-header-static">
        <span class="project-toggle">\u2022</span>
        <span class="project-title-block">
          <strong>Other Authenticated Orgs</strong>
          <small>Matched outside discovered projects</small>
        </span>
        <span class="project-count">${orgs.length}</span>
      </div>
      <div class="project-orgs">${orgs.map(renderOrgCard).join("")}</div>
    </section>
  `;
}
function renderSettingsPanel() {
  const roots = state.settings.roots.join("\n");
  return `
    <section class="settings-panel">
      <div class="settings-feature-card">
        <div>
          <div class="setup-kicker">Salesforce CLI auth</div>
          <h2>Connect a new org</h2>
          <p>Add Production, Sandbox, or a custom domain through Salesforce CLI web auth.</p>
        </div>
        <button type="button" class="secondary-button" data-action="toggleAuthPanel">${state.authPanelOpen ? "Hide Auth Form" : "Auth New Org"}</button>
      </div>
      ${renderAuthNewOrgPanel()}
      <div class="settings-grid">
        <label>
          <span>Theme</span>
          <select id="themeSelect">
            ${["light", "dark", "system"].map((mode) => `<option value="${mode}" ${state.settings.theme === mode ? "selected" : ""}>${mode}</option>`).join("")}
          </select>
        </label>
        <label>
          <span>Cache (minutes)</span>
          <input id="cacheDuration" type="number" min="1" max="240" value="${state.settings.cacheDurationMinutes}" />
        </label>
      </div>
      <label class="toggle-row">
        <input id="autoRefresh" type="checkbox" ${state.settings.autoRefresh ? "checked" : ""} />
        <span>Auto refresh from native host</span>
      </label>
      <label class="roots-label">
        <span>Project roots</span>
        <textarea id="rootsInput" rows="5">${escapeHtml(roots)}</textarea>
      </label>
      ${renderGroupBuilder()}
      <button type="button" class="save-settings" data-action="saveSettings">Save Settings</button>
    </section>
  `;
}
function renderResultsContent(projects = getProjectList(), others = getOtherOrgs()) {
  return `
    ${state.orgGroups.map(renderCustomGroup).join("")}
    ${projects.map(renderProject).join("")}
    ${others.length > 0 ? renderOtherOrgsSection(others) : ""}
    ${!state.loading && projects.length === 0 && others.length === 0 ? `<section class="empty-state">${state.data ? "No orgs matched the current search or CLI output." : "Click Refresh to scan configured project roots and load Salesforce CLI orgs."}</section>` : ""}
  `;
}
function renderResultsOnly() {
  const results = document.querySelector("#resultsContent");
  if (!results) {
    render();
    return;
  }
  results.innerHTML = renderResultsContent();
  bindActionElements(results);
}
function render() {
  const app = document.querySelector("#app");
  if (!app) {
    return;
  }
  const projects = getProjectList();
  const others = getOtherOrgs();
  const cliInfo = state.data?.cliInfo ?? state.cliInfo;
  const refreshSummary = state.loading ? "Loading orgs..." : state.statusRefreshing ? "Checking org status..." : state.statusMessage ? state.statusMessage : state.lastRefresh ? `Updated ${escapeHtml(formatDate(state.lastRefresh))}` : "Waiting for first load";
  app.innerHTML = `
    <style>
      :root {
        color-scheme: light;
        --bg: #eef3f5;
        --panel: rgba(255, 255, 255, 0.86);
        --panel-solid: #ffffff;
        --text: #16242b;
        --muted: #5f6f78;
        --accent: #0b7f8f;
        --accent-strong: #075f6f;
        --accent-soft: rgba(11, 127, 143, 0.12);
        --success: #0b7f52;
        --warning: #b26a00;
        --danger: #b83232;
        --danger-soft: rgba(184, 50, 50, 0.1);
        --border: rgba(22, 36, 43, 0.12);
        --shadow: 0 14px 34px rgba(20, 36, 45, 0.12);
        --hero: linear-gradient(145deg, #f7fbfc 0%, #eef3f5 48%, #dbe8ec 100%);
      }
      :root[data-theme="dark"] {
        color-scheme: dark;
        --bg: #0c1519;
        --panel: rgba(16, 29, 35, 0.88);
        --panel-solid: #12232a;
        --text: #edf5f7;
        --muted: #a7b9c0;
        --accent: #49c6d6;
        --accent-strong: #7bddeb;
        --accent-soft: rgba(73, 198, 214, 0.16);
        --success: #5ee0a8;
        --warning: #f3b35d;
        --danger: #ff8a8a;
        --danger-soft: rgba(255, 138, 138, 0.14);
        --border: rgba(126, 166, 189, 0.18);
        --shadow: 0 18px 45px rgba(0, 0, 0, 0.35);
        --hero: linear-gradient(145deg, #14262d 0%, #0c1519 56%, #11232a 100%);
      }
      * { box-sizing: border-box; }
      body { background: var(--bg); color: var(--text); }
      .shell {
        min-height: 700px;
        background: var(--hero);
        padding: 18px;
      }
      .hero {
        background: var(--panel);
        backdrop-filter: blur(18px);
        border: 1px solid var(--border);
        border-radius: 12px;
        box-shadow: var(--shadow);
        padding: 18px;
      }
      .hero-top {
        display: flex;
        align-items: start;
        justify-content: space-between;
        gap: 12px;
      }
      .title {
        margin: 0;
        font-size: 26px;
        line-height: 1;
        letter-spacing: 0;
      }
      .subtitle, .status-line, .project-header small, .org-username, .org-meta, .empty-state, .error-panel p, .setup-panel p, .setup-steps, .creator-credit {
        color: var(--muted);
      }
      .subtitle {
        margin: 8px 0 0;
        font-size: 13px;
      }
      .top-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: flex-end;
      }
      .icon-button, .primary-button, .secondary-button, .ghost-button, .org-actions button, .save-settings {
        border: 0;
        border-radius: 9px;
        padding: 10px 14px;
        background: var(--panel-solid);
        color: var(--text);
        cursor: pointer;
        border: 1px solid var(--border);
        font-weight: 760;
        transition: transform 120ms ease, background 120ms ease, border-color 120ms ease, box-shadow 120ms ease;
        max-width: 100%;
      }
      .icon-button:disabled, .primary-button:disabled, .secondary-button:disabled, .ghost-button:disabled, .org-actions button:disabled, .save-settings:disabled {
        cursor: not-allowed;
        opacity: 0.55;
        transform: none;
      }
      .primary-button {
        background: linear-gradient(135deg, var(--accent), var(--accent-strong));
        color: white;
        border-color: transparent;
        box-shadow: 0 10px 22px rgba(11, 127, 143, 0.22);
      }
      .secondary-button {
        background: var(--accent-soft);
        color: var(--accent-strong);
        border-color: rgba(11, 127, 143, 0.24);
      }
      .ghost-button {
        background: transparent;
        color: var(--muted);
      }
      .icon-button:hover, .primary-button:hover, .secondary-button:hover, .ghost-button:hover, .org-actions button:hover, .save-settings:hover {
        transform: translateY(-1px);
      }
      .search-bar {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 10px;
        margin-top: 18px;
      }
      .search-bar input, .group-create-row input, select, textarea, input[type="number"] {
        width: 100%;
        border-radius: 9px;
        border: 1px solid var(--border);
        background: var(--panel-solid);
        color: var(--text);
        padding: 12px 14px;
        font: inherit;
      }
      .status-line {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
        font-size: 12px;
        margin-top: 12px;
      }
      .status-line > span:last-child {
        flex: 0 0 auto;
        text-align: right;
      }
      .cli-pill {
        min-width: 0;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        max-width: 68%;
        padding: 7px 10px;
        border-radius: 999px;
        background: rgba(11, 127, 82, 0.11);
        color: var(--success);
        border: 1px solid rgba(11, 127, 82, 0.18);
      }
      .cli-pill > span:last-child {
        min-width: 0;
        display: grid;
        gap: 1px;
      }
      .cli-pill strong,
      .cli-pill small {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .cli-pill strong {
        font-size: 11px;
        line-height: 1.2;
      }
      .cli-pill small {
        color: var(--muted);
        font-size: 10px;
        font-weight: 700;
      }
      .cli-dot {
        flex: 0 0 auto;
        width: 8px;
        height: 8px;
        border-radius: 999px;
        background: currentColor;
        box-shadow: 0 0 0 3px rgba(11, 127, 82, 0.1);
      }
      .cli-pill-checking {
        background: var(--accent-soft);
        color: var(--accent);
        border-color: rgba(11, 127, 143, 0.18);
      }
      .cli-pill-error {
        background: var(--danger-soft);
        color: var(--danger);
        border-color: rgba(184, 50, 50, 0.22);
      }
      .content {
        display: grid;
        gap: 14px;
        margin-top: 16px;
      }
      .project-panel, .settings-panel, .error-panel, .empty-state, .setup-panel {
        background: var(--panel);
        border-radius: 12px;
        border: 1px solid var(--border);
        backdrop-filter: blur(14px);
        box-shadow: var(--shadow);
      }
      .group-builder-panel {
        background: linear-gradient(135deg, var(--accent-soft), var(--panel));
        border-radius: 12px;
        border: 1px solid var(--border);
        backdrop-filter: blur(14px);
        box-shadow: var(--shadow);
        padding: 16px;
      }
      .settings-feature-card {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 12px;
        align-items: center;
        padding: 14px;
        margin-bottom: 14px;
        border-radius: 12px;
        background:
          linear-gradient(135deg, var(--accent-soft), transparent),
          var(--panel-solid);
        border: 1px solid rgba(11, 127, 143, 0.18);
      }
      .settings-feature-card h2 {
        margin: 5px 0 5px;
        font-size: 18px;
      }
      .settings-feature-card p {
        margin: 0;
        color: var(--muted);
        font-size: 12px;
        line-height: 1.35;
      }
      .auth-new-panel {
        margin: 0 0 14px;
        padding: 16px;
        border-radius: 12px;
        border: 1px solid rgba(11, 127, 143, 0.2);
        background:
          radial-gradient(circle at top right, rgba(11, 127, 143, 0.16), transparent 34%),
          var(--panel-solid);
        box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.2);
      }
      .auth-new-panel[hidden] {
        display: none;
      }
      .auth-panel-copy h2 {
        margin: 6px 0 6px;
        font-size: 20px;
      }
      .auth-panel-copy p {
        margin: 0;
        color: var(--muted);
        font-size: 12px;
      }
      .auth-choice-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 10px;
        margin-top: 14px;
      }
      .auth-choice-card {
        display: grid;
        grid-template-columns: auto 1fr;
        align-items: center;
        gap: 8px;
        padding: 12px;
        border-radius: 11px;
        background: rgba(255, 255, 255, 0.42);
        border: 1px solid var(--border);
        cursor: pointer;
      }
      .auth-choice-card-active {
        border-color: rgba(11, 127, 143, 0.42);
        background: var(--accent-soft);
        box-shadow: inset 0 0 0 1px rgba(11, 127, 143, 0.14);
      }
      .auth-choice-card input {
        accent-color: var(--accent);
      }
      .auth-choice-card strong,
      .auth-choice-card small {
        display: block;
      }
      .auth-choice-card small {
        margin-top: 2px;
        color: var(--muted);
        font-size: 10px;
      }
      .auth-form-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 10px;
        margin-top: 12px;
      }
      .auth-form-grid label {
        display: grid;
        gap: 7px;
        font-size: 12px;
        font-weight: 760;
      }
      .auth-panel-actions,
      .remove-confirm-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
      }
      .auth-panel-actions {
        margin-top: 12px;
      }
      .group-builder-panel h2 {
        margin: 6px 0 8px;
        font-size: 20px;
        letter-spacing: 0;
      }
      .group-builder-panel p {
        color: var(--muted);
        margin: 0;
        font-size: 12px;
      }
      .group-create-row {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 10px;
        margin-top: 14px;
      }
      .group-toolbar {
        display: flex;
        justify-content: flex-end;
        padding: 0 14px 10px;
      }
      .group-toolbar button {
        border: 1px solid var(--border);
        border-radius: 9px;
        background: var(--panel-solid);
        color: var(--muted);
        cursor: pointer;
        padding: 7px 10px;
      }
      .project-header {
        all: unset;
        display: grid;
        grid-template-columns: auto minmax(0, 1fr) auto;
        align-items: center;
        gap: 12px;
        width: 100%;
        padding: 16px 18px;
        cursor: pointer;
      }
      .project-header-static {
        cursor: default;
      }
      .project-header:hover {
        background: rgba(255, 255, 255, 0.36);
      }
      .project-header-static:hover {
        background: transparent;
      }
      .project-toggle {
        font-size: 14px;
      }
      .project-title-block {
        min-width: 0;
        display: grid;
        gap: 4px;
      }
      .project-title-block strong,
      .project-title-block small {
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .project-header strong {
        line-height: 1.2;
      }
      .project-header small {
        font-size: 11px;
        line-height: 1.25;
      }
      .project-count {
        align-self: center;
        justify-self: end;
        min-width: 28px;
        max-width: 56px;
        height: 28px;
        padding: 0 9px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border-radius: 999px;
        background: var(--accent-soft);
        border: 1px solid rgba(11, 127, 143, 0.18);
        font-weight: 700;
        color: var(--accent);
        font-size: 12px;
        line-height: 1;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .project-orgs {
        display: grid;
        gap: 10px;
        padding: 0 14px 14px;
      }
      .org-card {
        background: var(--panel-solid);
        border-radius: 10px;
        border: 1px solid var(--border);
        padding: 14px;
        box-shadow: 0 8px 20px rgba(20, 36, 45, 0.06);
        overflow: hidden;
        min-width: 0;
      }
      .org-card-top, .org-alias-row {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        flex-wrap: wrap;
      }
      .org-card-top > div {
        min-width: 0;
        flex: 1 1 220px;
      }
      .org-alias-row {
        justify-content: flex-start;
      }
      .org-card h3 {
        margin: 0;
        font-size: 16px;
        max-width: 100%;
        overflow-wrap: anywhere;
      }
      .org-username {
        margin: 6px 0 0;
        font-size: 12px;
      }
      .org-meta {
        display: grid;
        gap: 4px;
        font-size: 11px;
        margin-top: 10px;
      }
      .org-meta span,
      .org-username {
        overflow-wrap: anywhere;
      }
      .org-status-help {
        margin-top: 10px;
        padding: 9px 10px;
        border-radius: 9px;
        background: rgba(178, 106, 0, 0.1);
        border: 1px solid rgba(178, 106, 0, 0.16);
        color: var(--warning);
        font-size: 11px;
        font-weight: 720;
        line-height: 1.35;
      }
      .org-actions {
        margin-top: 12px;
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
      }
      .org-actions button {
        font-size: 12px;
        padding: 8px 10px;
        min-width: 0;
        white-space: normal;
        line-height: 1.2;
      }
      .org-open-button {
        background: var(--accent) !important;
        border-color: transparent !important;
        color: white !important;
      }
      .org-copy-button {
        background: rgba(22, 36, 43, 0.035) !important;
        color: var(--muted) !important;
      }
      .danger-button {
        background: var(--danger-soft) !important;
        border-color: rgba(184, 50, 50, 0.22) !important;
        color: var(--danger) !important;
      }
      .remove-confirm-panel {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        gap: 12px;
        align-items: center;
        margin-top: 12px;
        padding: 12px;
        border-radius: 10px;
        background: var(--danger-soft);
        border: 1px solid rgba(184, 50, 50, 0.2);
      }
      .remove-confirm-panel strong {
        color: var(--danger);
      }
      .remove-confirm-panel p {
        margin: 4px 0 0;
        color: var(--muted);
        font-size: 11px;
        line-height: 1.35;
      }
      .org-actions .group-select {
        width: 100%;
        min-width: 0;
        border-radius: 9px;
        padding: 8px 10px;
        font-size: 12px;
      }
      .favorite-button {
        border: 1px solid var(--border);
        border-radius: 9px;
        background: rgba(255, 255, 255, 0.5);
        color: var(--warning);
        font-size: 20px;
        cursor: pointer;
        width: 38px;
        height: 38px;
      }
      .badge {
        display: inline-flex;
        padding: 4px 8px;
        border-radius: 7px;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 0;
        text-transform: uppercase;
      }
      .badge-default { background: var(--accent-soft); color: var(--accent); }
      .badge-accent { background: rgba(178, 106, 0, 0.14); color: var(--warning); }
      .badge-neutral { background: rgba(102, 136, 153, 0.14); color: var(--muted); }
      .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 8px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 800;
      }
      .status-badge::before {
        content: "";
        width: 6px;
        height: 6px;
        border-radius: 999px;
        background: currentColor;
      }
      .status-connected {
        color: var(--success);
        background: rgba(11, 127, 82, 0.11);
        border: 1px solid rgba(11, 127, 82, 0.16);
      }
      .status-checking {
        color: var(--accent);
        background: var(--accent-soft);
        border: 1px solid rgba(11, 127, 143, 0.16);
      }
      .status-expired {
        color: var(--danger);
        background: var(--danger-soft);
        border: 1px solid rgba(184, 50, 50, 0.2);
      }
      .status-unreachable {
        color: var(--warning);
        background: rgba(178, 106, 0, 0.12);
        border: 1px solid rgba(178, 106, 0, 0.2);
      }
      .status-unknown {
        color: var(--muted);
        background: rgba(102, 136, 153, 0.14);
        border: 1px solid rgba(102, 136, 153, 0.18);
      }
      .settings-panel, .error-panel, .empty-state, .setup-panel {
        padding: 16px;
      }
      .setup-panel h2 {
        margin: 6px 0 8px;
        font-size: 20px;
        letter-spacing: 0;
      }
      .setup-kicker {
        color: var(--accent);
        font-size: 11px;
        font-weight: 800;
        letter-spacing: 0;
        text-transform: uppercase;
      }
      .setup-steps {
        display: grid;
        gap: 6px;
        font-size: 12px;
        margin: 12px 0;
      }
      .setup-command {
        display: block;
        white-space: normal;
        word-break: break-word;
        padding: 12px;
        border-radius: 9px;
        background: rgba(22, 36, 43, 0.08);
        border: 1px solid var(--border);
        font-size: 12px;
      }
      .setup-link-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
        margin: 14px 0 2px;
      }
      .setup-os-grid {
        display: grid;
        gap: 10px;
        margin-top: 12px;
      }
      .setup-os-card {
        background: var(--panel-solid);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 12px;
      }
      .setup-os-card-active {
        box-shadow: inset 0 0 0 1px rgba(11, 127, 171, 0.25);
      }
      .setup-os-row, .setup-os-actions {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        flex-wrap: wrap;
      }
      .setup-os-actions {
        margin-top: 10px;
      }
      .setup-link-grid .icon-button,
      .setup-link-grid .primary-button {
        width: 100%;
      }
      .setup-actions {
        display: flex;
        gap: 10px;
        margin-top: 12px;
        flex-wrap: wrap;
      }
      .settings-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }
      .settings-panel label {
        display: grid;
        gap: 8px;
        font-size: 12px;
      }
      .toggle-row {
        margin-top: 12px;
        display: flex !important;
        align-items: center;
        gap: 10px;
      }
      .roots-label {
        margin-top: 12px;
      }
      .save-settings {
        margin-top: 12px;
        width: 100%;
      }
      .empty-state {
        text-align: center;
        font-size: 13px;
      }
      .loader {
        height: 3px;
        background: linear-gradient(90deg, transparent, var(--accent), transparent);
        background-size: 200% 100%;
        animation: slide 1.2s linear infinite;
        border-radius: 999px;
        margin-top: 12px;
      }
      .creator-credit {
        margin-top: 16px;
        padding: 12px 4px 2px;
        text-align: center;
        font-size: 11px;
      }
      .creator-credit a {
        color: var(--accent-strong);
        font-weight: 800;
        text-decoration: none;
      }
      .creator-credit a:hover {
        text-decoration: underline;
      }
      .app-version {
        display: block;
        clear: both;
        margin-top: 6px;
        width: 100%;
      }
      @keyframes slide {
        from { background-position: 200% 0; }
        to { background-position: -200% 0; }
      }
      @media (max-width: 560px) {
        .settings-feature-card,
        .auth-choice-grid,
        .auth-form-grid,
        .remove-confirm-panel {
          grid-template-columns: 1fr;
        }
      }
    </style>

    <div class="shell">
      <section class="hero">
        <div class="hero-top">
          <div>
            <h1 class="title">Salesforce CLI Org Launcher</h1>
            <p class="subtitle">Project-first access to every authenticated Salesforce CLI org.</p>
          </div>
          <div class="top-actions">
            <button type="button" class="icon-button" data-action="toggleSettings">Settings</button>
            <button type="button" class="primary-button" data-action="refresh">Refresh</button>
          </div>
        </div>
        <div class="search-bar">
          <input id="searchInput" value="${escapeHtml(state.searchQuery)}" placeholder="Search alias, username, org ID, URL, or project" />
          <button type="button" class="icon-button" data-action="clearSearch">Clear</button>
        </div>
        <div class="status-line">
          ${renderCliStatus(cliInfo)}
          <span>${refreshSummary}</span>
        </div>
        ${state.loading ? '<div class="loader"></div>' : ""}
      </section>

      <div class="content">
        ${nativeHostSetupNeeded() ? renderSetupPanel() : ""}
        ${state.error && !nativeHostSetupNeeded() ? `<section class="error-panel"><strong>Unable to load data</strong><p>${escapeHtml(state.error)}</p></section>` : ""}
        ${renderSettingsPanel()}
        <div id="resultsContent" class="results-content">
          ${renderResultsContent(projects, others)}
        </div>
        <footer class="creator-credit">
          Crafted with \u2764\uFE0F by <a href="https://www.linkedin.com/in/kiranmarkad" data-action="openExternal" data-value="https://www.linkedin.com/in/kiranmarkad">Kiran Markad</a>.
          <span class="app-version">v${APP_VERSION}</span>
        </footer>
      </div>
    </div>
  `;
  const settingsPanel = app.querySelector(".settings-panel");
  document.body.classList.toggle("show-settings", settingsOpen);
  if (settingsPanel) {
    settingsPanel.hidden = !settingsOpen;
  }
  bindActionElements(app);
}
function syncSettingsPanelVisibility() {
  document.body.classList.toggle("show-settings", settingsOpen);
  const settingsPanel = document.querySelector(".settings-panel");
  if (settingsPanel) {
    settingsPanel.hidden = !settingsOpen;
    if (settingsOpen) {
      settingsPanel.scrollIntoView({ block: "nearest" });
    }
  }
}
async function toggleFavorite(value) {
  state.favorites = state.favorites.includes(value) ? state.favorites.filter((item) => item !== value) : [value, ...state.favorites];
  render();
  await setLocalStorage({ favorites: state.favorites });
}
async function toggleProject(name) {
  state.expandedProjects = state.expandedProjects.includes(name) ? state.expandedProjects.filter((item) => item !== name) : [...state.expandedProjects, name];
  await setLocalStorage({ expandedProjects: state.expandedProjects });
  render();
}
async function saveGroups() {
  await setLocalStorage({
    orgGroups: state.orgGroups,
    expandedGroups: state.expandedGroups
  });
}
async function createGroup(name, initialOrgKey) {
  const cleanName = name.trim();
  if (!cleanName) {
    state.error = "Enter a group name first.";
    render();
    return;
  }
  const group = {
    id: `group-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: cleanName,
    orgKeys: initialOrgKey ? [initialOrgKey] : []
  };
  state.orgGroups = [group, ...state.orgGroups];
  state.expandedGroups = [group.id, ...state.expandedGroups];
  state.error = void 0;
  render();
  await saveGroups();
}
async function toggleGroup(groupId) {
  state.expandedGroups = state.expandedGroups.includes(groupId) ? state.expandedGroups.filter((item) => item !== groupId) : [...state.expandedGroups, groupId];
  render();
  await saveGroups();
}
async function addOrgToGroup(groupId, key) {
  state.orgGroups = state.orgGroups.map((group) => {
    if (group.id !== groupId || groupContainsOrg(group, key)) {
      return group;
    }
    return { ...group, orgKeys: [...group.orgKeys, key] };
  });
  render();
  await saveGroups();
}
async function removeOrgFromGroup(groupId, key) {
  state.orgGroups = state.orgGroups.map(
    (group) => group.id === groupId ? { ...group, orgKeys: group.orgKeys.filter((item) => item !== key) } : group
  );
  render();
  await saveGroups();
}
async function deleteGroup(groupId) {
  state.orgGroups = state.orgGroups.filter((group) => group.id !== groupId);
  state.expandedGroups = state.expandedGroups.filter((item) => item !== groupId);
  render();
  await saveGroups();
}
async function saveSettings() {
  const rootsInput = document.querySelector("#rootsInput");
  const cacheInput = document.querySelector("#cacheDuration");
  const autoRefresh = document.querySelector("#autoRefresh");
  const themeSelect = document.querySelector("#themeSelect");
  const settings = {
    roots: rootsInput?.value.split("\n").map((item) => item.trim()).filter(Boolean) ?? DEFAULT_SETTINGS.roots,
    cacheDurationMinutes: Number(cacheInput?.value ?? DEFAULT_SETTINGS.cacheDurationMinutes),
    autoRefresh: autoRefresh?.checked ?? true,
    theme: themeSelect?.value ?? "system"
  };
  state.settings = settings;
  applyTheme(settings.theme);
  await sendMessage({ type: "saveSettings", settings });
  await refreshData(true);
}
function decodeOrgActionValue(value) {
  try {
    return JSON.parse(decodeURIComponent(value));
  } catch {
    return {};
  }
}
async function reauthorizeOrg(value) {
  const org = decodeOrgActionValue(value);
  const result = await sendMessage({
    type: "reauthorizeOrg",
    alias: org.alias,
    username: org.username,
    instanceUrl: org.instanceUrl
  }, 15e3);
  if (!result.success) {
    state.error = result.error ?? "Unable to start Salesforce login.";
    render();
    return;
  }
  state.error = void 0;
  state.statusMessage = result.message ?? "Complete Salesforce login in the browser, then click Check Again.";
  render();
}
async function authorizeNewOrg() {
  const selectedEnvironment = document.querySelector('input[name="authEnvironment"]:checked')?.value;
  const environment = selectedEnvironment ?? state.authEnvironment ?? "production";
  const aliasInput = document.querySelector("#newOrgAlias");
  const customUrlInput = document.querySelector("#customInstanceUrl");
  const instanceUrl = environment === "custom" ? customUrlInput?.value.trim() ?? "" : instanceUrlForEnvironment(environment);
  if (!instanceUrl) {
    state.error = "Enter a custom Salesforce login URL first.";
    render();
    return;
  }
  let result = await sendMessage({
    type: "authorizeNewOrg",
    alias: aliasInput?.value.trim() || void 0,
    instanceUrl
  }, 15e3);
  if (!result.success && result.error === "Unknown message.") {
    result = await sendNativeMessage({
      action: "authorizeNewOrg",
      alias: aliasInput?.value.trim() || void 0,
      instanceUrl
    }, 15e3);
  }
  if (!result.success) {
    state.error = result.error === "Unknown message." ? "The extension service worker is still running an older build. Reload the extension from chrome://extensions, then try Auth New Org again." : result.error ?? "Unable to start Salesforce login.";
    render();
    return;
  }
  state.authPanelOpen = false;
  state.error = void 0;
  state.statusMessage = result.message ?? "Complete Salesforce login in the browser, then click Refresh.";
  render();
}
async function openOrgSetup(alias) {
  if (!alias) {
    state.error = "This org is missing an alias or username, so Salesforce CLI cannot open Setup.";
    render();
    return;
  }
  const org = findOrgByKey(alias);
  if (org && !canOpenOrg(org)) {
    state.error = getOrgConnectionStatus(org) === "expired" ? "This org needs authorization before Setup can be opened." : "This org is unreachable right now. Check status or authorize again.";
    render();
    return;
  }
  let result = await sendMessage({ type: "openOrgSetup", alias });
  if (!result.success && result.error === "Unknown message.") {
    result = await sendNativeMessage({
      action: "openOrgSetup",
      alias
    });
    if (result.success && result.url) {
      await openTab(result.url);
    }
  }
  if (!result.success) {
    state.error = result.error ?? "Unable to open Setup.";
    render();
  }
}
function requestRemoveOrg(value) {
  const org = decodeOrgActionValue(value);
  const key = org.alias || org.username;
  if (!key) {
    state.error = "This org is missing an alias or username, so Salesforce CLI cannot remove it.";
    render();
    return;
  }
  pendingRemoveOrgKey = key;
  state.error = void 0;
  render();
}
async function confirmRemoveOrg(value) {
  const org = decodeOrgActionValue(value);
  const result = await sendMessage({
    type: "removeOrg",
    alias: org.alias,
    username: org.username
  }, 5e4);
  if (!result.success) {
    state.error = result.error ?? "Unable to remove org from Salesforce CLI.";
    render();
    return;
  }
  pendingRemoveOrgKey = "";
  state.error = void 0;
  await refreshData(true);
  state.statusMessage = result.message ?? "Org authorization removed from Salesforce CLI.";
  render();
}
async function handleActionEvent(event) {
  const target = event.target;
  const actionTarget = target?.closest("[data-action]");
  const action = actionTarget?.dataset.action;
  const value = actionTarget?.dataset.value ?? "";
  if (!action) {
    return;
  }
  event.preventDefault();
  event.stopPropagation();
  if (action === "refresh") {
    await refreshData(true);
    return;
  }
  if (action === "checkStatus") {
    await refreshOrgStatuses(true);
    return;
  }
  if (action === "reauthorizeOrg") {
    await reauthorizeOrg(value);
    return;
  }
  if (action === "toggleAuthPanel") {
    state.authPanelOpen = !state.authPanelOpen;
    state.error = void 0;
    render();
    return;
  }
  if (action === "selectAuthEnvironment") {
    state.authEnvironment = value || "production";
    render();
    return;
  }
  if (action === "authorizeNewOrg") {
    await authorizeNewOrg();
    return;
  }
  if (action === "askRemoveOrg") {
    requestRemoveOrg(value);
    return;
  }
  if (action === "confirmRemoveOrg") {
    await confirmRemoveOrg(value);
    return;
  }
  if (action === "cancelRemoveOrg") {
    pendingRemoveOrgKey = "";
    render();
    return;
  }
  if (action === "toggleSettings") {
    settingsOpen = !settingsOpen;
    syncSettingsPanelVisibility();
    return;
  }
  if (action === "clearSearch") {
    state.searchQuery = "";
    render();
    return;
  }
  if (action === "copySetupCommand") {
    await navigator.clipboard.writeText(value);
    return;
  }
  if (action === "toggleProject") {
    await toggleProject(value);
    return;
  }
  if (action === "toggleGroup") {
    await toggleGroup(value);
    return;
  }
  if (action === "favorite") {
    await toggleFavorite(value);
    return;
  }
  if (action === "createGroup") {
    const input = document.querySelector("#newGroupName");
    await createGroup(input?.value ?? "");
    if (input) {
      input.value = "";
    }
    return;
  }
  if (action === "createGroupForOrg") {
    const groupName = window.prompt("Group name for this org");
    if (groupName) {
      await createGroup(groupName, value);
    }
    return;
  }
  if (action === "addToSelectedGroup") {
    const select = document.querySelector(`.group-select[data-org-key="${CSS.escape(value)}"]`);
    if (select?.value) {
      await addOrgToGroup(select.value, value);
    }
    return;
  }
  if (action === "removeFromGroup") {
    await removeOrgFromGroup(actionTarget?.dataset.groupId ?? "", value);
    return;
  }
  if (action === "deleteGroup") {
    await deleteGroup(value);
    return;
  }
  if (action === "saveSettings") {
    await saveSettings();
    return;
  }
  if (action === "open") {
    if (!value) {
      state.error = "This org is missing an alias or username, so Salesforce CLI cannot open it.";
      render();
      return;
    }
    const org = findOrgByKey(value);
    if (org && !canOpenOrg(org)) {
      state.error = getOrgConnectionStatus(org) === "expired" ? "This org needs authorization before it can be opened." : "This org is unreachable right now. Check status or authorize again.";
      render();
      return;
    }
    const result = await sendMessage({ type: "openOrg", alias: value });
    if (!result.success) {
      state.error = result.error ?? "Unable to open org.";
      render();
    }
    return;
  }
  if (action === "openSetup") {
    await openOrgSetup(value);
    return;
  }
  if (action === "openExternal") {
    event.preventDefault();
    await sendMessage({ type: "openExternal", url: value });
    return;
  }
  const copyMap = {
    copyUsername: value,
    copyOrgId: value,
    copyUrl: value
  };
  if (action in copyMap) {
    await navigator.clipboard.writeText(copyMap[action] ?? "");
  }
}
function bindActionElements(root) {
  root.querySelectorAll("[data-action]").forEach((element) => {
    element.onmousedown = dispatchActionEvent;
    element.onpointerup = dispatchActionEvent;
    element.onclick = dispatchActionEvent;
    element.onkeydown = (event) => {
      if (event.key === "Enter" || event.key === " ") {
        dispatchActionEvent(event);
      }
    };
  });
}
function shouldHandleActionEvent(event) {
  const target = event.target;
  const actionTarget = target?.closest("[data-action]");
  const action = actionTarget?.dataset.action;
  if (!actionTarget || !action) {
    return false;
  }
  const key = `${action}:${actionTarget.dataset.value ?? ""}:${actionTarget.dataset.groupId ?? ""}`;
  const now = Date.now();
  if (lastActionKey === key && now - lastActionAt < HANDLED_ACTION_WINDOW_MS) {
    return false;
  }
  lastActionKey = key;
  lastActionAt = now;
  return true;
}
function dispatchActionEvent(event) {
  if (!shouldHandleActionEvent(event)) {
    return;
  }
  void handleActionEvent(event);
}
document.addEventListener("mousedown", dispatchActionEvent, true);
document.addEventListener("pointerup", dispatchActionEvent, true);
document.addEventListener("click", dispatchActionEvent, true);
document.addEventListener("keydown", (event) => {
  if (event.key === "Enter" || event.key === " ") {
    dispatchActionEvent(event);
  }
}, true);
document.addEventListener("input", (event) => {
  const target = event.target;
  if (target?.id === "searchInput") {
    state.searchQuery = target.value;
    renderResultsOnly();
  }
}, true);
void loadBootstrapState().catch((error) => {
  state.loading = false;
  state.error = error instanceof Error ? error.message : String(error);
  render();
});
//# sourceMappingURL=popup.js.map
