// extension/src/background.ts
var HOST_NAME = "com.kiran.salesforce_org_launcher";
var DEFAULT_SETTINGS = {
  roots: ["~/Projects", "~/Development", "~/workspace", "~/Documents"],
  theme: "system",
  autoRefresh: true,
  cacheDurationMinutes: 15
};
async function getStorage(key, fallback) {
  const result = await new Promise((resolve, reject) => {
    chrome.storage.local.get(key, (items) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(items);
    });
  });
  return result[key] ?? fallback;
}
async function callNativeHost(request, timeoutMs = 3e4) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timer = setTimeout(() => {
      if (settled) {
        return;
      }
      settled = true;
      reject(new Error("Native host did not respond before the timeout. Reinstall the companion native host, then reload the extension."));
    }, timeoutMs);
    chrome.runtime.sendNativeMessage(HOST_NAME, request, (response) => {
      if (settled) {
        return;
      }
      settled = true;
      clearTimeout(timer);
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(response);
    });
  });
}
async function getCachedData() {
  return getStorage("cache", {});
}
async function getCachedOrgStatuses() {
  return getStorage("orgStatusCache", { statuses: {}, fetchedAt: "" });
}
async function setCachedData(payload) {
  await setLocalStorage({
    cache: {
      payload,
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString()
    }
  });
}
async function setLocalStorage(values) {
  await new Promise((resolve, reject) => {
    chrome.storage.local.set(values, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve();
    });
  });
}
async function clearOrgCaches() {
  await setLocalStorage({
    cache: {},
    orgStatusCache: { statuses: {}, fetchedAt: "" }
  });
}
async function createTab(url) {
  await new Promise((resolve, reject) => {
    chrome.tabs.create({ url }, () => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve();
    });
  });
}
async function shouldUseCache(settings, forceRefresh) {
  if (forceRefresh || !settings.autoRefresh) {
    return false;
  }
  const cache = await getCachedData();
  if (!cache.payload || !cache.fetchedAt) {
    return false;
  }
  const ageMs = Date.now() - new Date(cache.fetchedAt).getTime();
  return ageMs < settings.cacheDurationMinutes * 6e4;
}
async function handleGetData(forceRefresh) {
  const settings = await getStorage("settings", DEFAULT_SETTINGS);
  if (await shouldUseCache(settings, forceRefresh)) {
    const cache = await getCachedData();
    if (cache.payload) {
      return { ok: true, payload: cache.payload, cached: true };
    }
  }
  const payload = await callNativeHost({
    action: "listProjects",
    roots: settings.roots
  });
  await setCachedData(payload);
  return { ok: true, payload, cached: false };
}
function statusKeys(status) {
  return [status.key, status.alias, status.username, status.orgId].map((value) => String(value || "").toLowerCase()).filter(Boolean);
}
async function handleRefreshOrgStatuses(forceRefresh) {
  const cache = await getCachedOrgStatuses();
  const cacheAgeMs = cache.fetchedAt ? Date.now() - new Date(cache.fetchedAt).getTime() : Number.POSITIVE_INFINITY;
  if (!forceRefresh && cache.fetchedAt && cacheAgeMs < 15 * 6e4) {
    return { ok: true, statuses: cache.statuses, fetchedAt: cache.fetchedAt, cached: true };
  }
  const response = await callNativeHost({ action: "refreshOrgStatuses" }, 12e4);
  if (!response.success) {
    return { ok: false, error: response.error ?? "Unable to refresh org statuses.", statuses: cache.statuses, fetchedAt: cache.fetchedAt };
  }
  const fetchedAt = response.checkedAt ?? (/* @__PURE__ */ new Date()).toISOString();
  const statuses = {};
  for (const status of response.statuses ?? []) {
    for (const key of statusKeys(status)) {
      statuses[key] = status;
    }
  }
  await setLocalStorage({ orgStatusCache: { statuses, fetchedAt } });
  return { ok: true, statuses, fetchedAt, cached: false };
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case "ping":
        sendResponse({ ok: true, awake: true });
        break;
      case "detectCli":
        sendResponse({ ok: true, cliInfo: await callNativeHost({ action: "detect" }, 1e4) });
        break;
      case "getData":
        sendResponse(await handleGetData(message.forceRefresh));
        break;
      case "getCachedData": {
        const cache = await getCachedData();
        sendResponse({ ok: true, payload: cache.payload, fetchedAt: cache.fetchedAt });
        break;
      }
      case "openOrg": {
        const response = await callNativeHost({ action: "openOrg", alias: message.alias });
        if (response.success && response.url) {
          await createTab(response.url);
        }
        sendResponse(response);
        break;
      }
      case "openOrgSetup": {
        const response = await callNativeHost({ action: "openOrgSetup", alias: message.alias });
        if (response.success && response.url) {
          await createTab(response.url);
        }
        sendResponse(response);
        break;
      }
      case "refreshOrgStatuses":
        sendResponse(await handleRefreshOrgStatuses(message.forceRefresh));
        break;
      case "reauthorizeOrg":
        sendResponse(await callNativeHost({
          action: "reauthorizeOrg",
          alias: message.alias,
          username: message.username,
          instanceUrl: message.instanceUrl
        }, 12e3));
        break;
      case "authorizeNewOrg":
        sendResponse(await callNativeHost({
          action: "authorizeNewOrg",
          alias: message.alias,
          instanceUrl: message.instanceUrl
        }, 12e3));
        break;
      case "removeOrg": {
        const response = await callNativeHost({
          action: "removeOrg",
          alias: message.alias,
          username: message.username
        }, 45e3);
        if (response.success) {
          await clearOrgCaches();
        }
        sendResponse(response);
        break;
      }
      case "openExternal":
        await createTab(message.url);
        sendResponse({ ok: true });
        break;
      case "getSettings":
        sendResponse({ ok: true, settings: await getStorage("settings", DEFAULT_SETTINGS) });
        break;
      case "saveSettings":
        await setLocalStorage({ settings: message.settings });
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, error: "Unknown message." });
    }
  })().catch((error) => {
    sendResponse({ ok: false, error: error instanceof Error ? error.message : String(error) });
  });
  return true;
});
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    void createTab(chrome.runtime.getURL("popup.html?onboarding=1"));
  }
});
//# sourceMappingURL=background.js.map
