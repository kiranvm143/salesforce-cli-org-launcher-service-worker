#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$(uname -s)" = "Darwin" ]; then
  TARGET_OS="mac"
else
  TARGET_OS="linux"
fi
CHROME_EXTENSION_IDS="${CHROME_EXTENSION_IDS:-kanjinfiojebibldeeajnbmgjmdipjjn,nmjgfcdchchicaophfglfeijceibpkde,aigfbbnieiipffbjinoccnbocfhlkepm}" node scripts/install-native-host.mjs "$TARGET_OS"
echo "Native host installed for $TARGET_OS."
echo "Open the Chrome extension and click Refresh."
