# Chrome Web Store Publishing

App name: Salesforce CLI Org Launcher

An AI-powered utility, crafted with ❤️ by [Kiran Markad](https://www.linkedin.com/in/kiranmarkad).

## Build Artifacts

Run:

```bash
npm run package
```

Publish this ZIP in the Chrome Web Store Developer Dashboard:

```text
release/SalesforceOrgLauncher-chrome-web-store.zip
```

Use this ZIP for dashboard listing assets, screenshots, privacy copy, and reviewer notes:

```text
release/SalesforceOrgLauncher-webstore-assets.zip
```

Do not upload the portable companion ZIP to the Chrome Web Store. It contains native-host installers and platform launchers, which are intentionally separate from the browser extension package.

## Companion Installer

Share this ZIP as the native-host companion installer:

```text
release/SalesforceOrgLauncher-portable-mac-windows-linux.zip
```

Chrome Web Store can install the browser extension, but Chrome does not allow an extension to silently register a native messaging host on the local machine. Each machine must run the companion installer once.

The companion installer copies the native host runtime into the user's app-data folder before registration. This is intentional: it keeps the helper stable after install and avoids repeatedly running it from protected locations such as Desktop or Downloads.

## First Upload Flow

1. Run `npm run package`.
2. Upload `release/SalesforceOrgLauncher-chrome-web-store.zip` to the Chrome Web Store Developer Dashboard.
3. Copy the extension ID assigned by Chrome Web Store.
4. Rebuild the companion installer with that ID:

```bash
CHROME_EXTENSION_ID=<chrome-web-store-extension-id> npm run package
```

5. Distribute `release/SalesforceOrgLauncher-portable-mac-windows-linux.zip` as the companion installer.

## Target Machine Install

After installing the extension from Chrome Web Store, the extension opens a setup tab automatically.

macOS/Linux:

```bash
chmod +x install-mac-linux.sh
./install-mac-linux.sh
```

Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-windows.ps1
```

Then open the extension popup and click **Refresh**.

On macOS, folder access prompts are controlled by Apple privacy protections. Users should only see a prompt when the helper scans a protected project root such as Desktop, Documents, or Downloads; normal popup opens use cached data and do not rescan folders automatically.

## Store Listing Notes

- Mention that Node.js 20+ and Salesforce CLI are required.
- Mention that the extension needs the companion native host for local Salesforce CLI access.
- Use `release/SalesforceOrgLauncher/extension/icons/icon128.png` as the listing icon if needed.
- Keep the Web Store ZIP separate from native binaries and installers.
- Use the generated 1280x800 screenshots from `store-assets/screenshots`.
- Publish `store-assets/privacy/PRIVACY_POLICY.md` as a public web page and use that URL in the Chrome Web Store privacy policy field.
- Recommended GitHub Pages privacy URL after publishing this repo:
  `https://kiranvm143.github.io/salesforce-cli-org-launcher-service-worker/docs/privacy-policy.html`
- Use `store-assets/listing/CHROME_WEB_STORE_LISTING.md` for the final listing copy.
- Use `store-assets/listing/REVIEWER_NOTES.md` in the reviewer notes field.

## Public GitHub Documentation Repository

Only the Manifest V3 service worker files and related documentation should be published publicly:

```text
/Users/kiranmarkad/Desktop/salesforce-cli-org-launcher-service-worker
```

Recommended public repository name:

```text
salesforce-cli-org-launcher-service-worker
```

This keeps the service worker, privacy policy, and Chrome permission documentation public while keeping the full extension application source private.
