# Salesforce CLI Org Launcher Portable Install

An AI-powered utility, crafted with ❤️ by [Kiran Markad](https://www.linkedin.com/in/kiranmarkad).

Extension ID: `nmjgfcdchchicaophfglfeijceibpkde`

## Prerequisites

- Google Chrome or Chromium
- Node.js 20+
- Salesforce CLI, either `sf` or `sfdx`

## Install Chrome Extension

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click **Load unpacked**.
4. Select the `extension` folder from this package.

## Register Native Host

macOS or Linux:

```bash
chmod +x install-mac-linux.sh
./install-mac-linux.sh
```

Windows PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-windows.ps1
```

## Verify

Open the extension popup, click **Refresh**, and open an org.
