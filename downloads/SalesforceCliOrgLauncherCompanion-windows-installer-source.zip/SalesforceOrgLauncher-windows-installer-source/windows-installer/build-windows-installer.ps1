param(
  [string]$ExtensionId = "kanjinfiojebibldeeajnbmgjmdipjjn"
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$IssPath = Join-Path $ScriptDir "SalesforceCliOrgLauncherCompanion.iss"

$iscc = Get-Command ISCC.exe -ErrorAction SilentlyContinue
if (-not $iscc) {
  $candidates = @(
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path $candidate)) {
      $iscc = Get-Item $candidate
      break
    }
  }
}

if (-not $iscc) {
  throw "Inno Setup 6 is required. Install it from https://jrsoftware.org/isinfo.php, then rerun this script."
}

$isccPath = if ($iscc.Source) { $iscc.Source } else { $iscc.FullName }
& $isccPath "/DChromeExtensionId=$ExtensionId" $IssPath
if ($LASTEXITCODE -ne 0) {
  exit $LASTEXITCODE
}

Write-Host "Windows installer created:"
Write-Host (Join-Path $ScriptDir "output\SalesforceCliOrgLauncherCompanionSetup.exe")
