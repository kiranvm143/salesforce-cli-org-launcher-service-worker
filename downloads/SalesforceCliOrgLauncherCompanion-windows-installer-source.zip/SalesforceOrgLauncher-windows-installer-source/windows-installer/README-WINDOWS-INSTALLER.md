# Windows Installer Builder

This folder builds a one-click Windows installer for the Salesforce CLI Org Launcher companion native host.

The Chrome Web Store package installs the browser extension. This Windows installer installs the local native messaging host that lets Chrome talk to Salesforce CLI.

## Build on Windows

1. Install Node.js 20+ and Salesforce CLI on the target machine or image.
2. Install Inno Setup 6 from https://jrsoftware.org/isinfo.php.
3. Open PowerShell in this folder.
4. Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\build-windows-installer.ps1
```

The output is:

```text
output\SalesforceCliOrgLauncherCompanionSetup.exe
```

## What the Installer Does

- Copies the native host runtime into `%LOCALAPPDATA%\Salesforce CLI Org Launcher\native-host`.
- Writes the Chrome native messaging manifest into `%LOCALAPPDATA%\SalesforceOrgLauncher\NativeMessagingHosts`.
- Registers `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.kiran.salesforce_org_launcher`.
- Does not require administrator rights.
- Does not request website access permissions.

## End User Flow

1. Install the Chrome extension from Chrome Web Store.
2. Run `SalesforceCliOrgLauncherCompanionSetup.exe` once.
3. Open the extension and click **Refresh**.
