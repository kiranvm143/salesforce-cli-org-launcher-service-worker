param(
  [string]$ExtensionIds = "kanjinfiojebibldeeajnbmgjmdipjjn,nmjgfcdchchicaophfglfeijceibpkde,aigfbbnieiipffbjinoccnbocfhlkepm"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:CHROME_EXTENSION_IDS = $ExtensionIds
node scripts/install-native-host.mjs windows
Write-Host "Native host installed for Windows."
Write-Host "Open the Chrome extension and click Refresh."
