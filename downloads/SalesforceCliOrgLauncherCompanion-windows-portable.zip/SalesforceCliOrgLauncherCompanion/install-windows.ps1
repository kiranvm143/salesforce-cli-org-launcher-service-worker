param(
  [string]$ExtensionId = "nmjgfcdchchicaophfglfeijceibpkde"
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:CHROME_EXTENSION_ID = $ExtensionId
node scripts/install-native-host.mjs windows
Write-Host "Native host installed for Windows."
Write-Host "Load the extension folder in Chrome: $PSScriptRoot\extension"
