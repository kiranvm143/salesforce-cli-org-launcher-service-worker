# Salesforce CLI Org Launcher Companion

An AI-powered utility, crafted with love by [Kiran Markad](https://www.linkedin.com/in/kiranmarkad).

Chrome Web Store installs the browser extension. This companion package installs the local native messaging host that lets the extension talk to Salesforce CLI on your computer.

Chrome Web Store extension ID:

```text
nmjgfcdchchicaophfglfeijceibpkde
```

## Requirements

- Google Chrome or Chromium
- Node.js 20 or later
- Salesforce CLI installed and authenticated with `sf` or `sfdx`
- Salesforce CLI Org Launcher installed from Chrome Web Store

## macOS

Open Terminal in this folder and run:

```bash
chmod +x install-mac-linux.sh
./install-mac-linux.sh
```

If macOS asks whether `native-launcher` can access Desktop, Documents, or Downloads, click **Allow** if your Salesforce projects are stored there.

## Linux

Open Terminal in this folder and run:

```bash
chmod +x install-mac-linux.sh
./install-mac-linux.sh
```

## Windows

Open PowerShell in this folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install-windows.ps1
```

## Verify

1. Open Chrome.
2. Open the Salesforce CLI Org Launcher extension.
3. Click **Refresh**.
4. Confirm orgs appear.
5. Click **Open** on an org.

If the extension says the CLI or native host is not detected, confirm `sf org list` works in Terminal or PowerShell, then rerun the companion installer.
