import { execFile } from "node:child_process";
import { promisify } from "node:util";
import path from "node:path";
import { fileURLToPath } from "node:url";

const execFileAsync = promisify(execFile);
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const hostPath = path.join(root, "dist", "native-host", "index.js");

const { stdout } = await execFileAsync("node", [hostPath, "--smoke"], {
  env: { ...process.env, SFDX_LAUNCHER_TEST_MODE: "1" }
});

console.log(stdout.trim());
